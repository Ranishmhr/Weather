import React from "react";

const Moreinfo = props => (
<div>
    {

    }
</div>
);
export default Moreinfo;