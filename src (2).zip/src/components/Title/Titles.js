import React from "react";
import './Title.css';
const Titles = () => (
	<div className="title">
		<h1>Weather</h1>
	</div>
);

export default Titles;