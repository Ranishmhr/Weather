import React from "react";
import Body from './container/Body/Body'


class App extends React.Component {
  
  render(){
   
    return(
      <div className="App">
        <Body/>
      </div>
    );
  }
}
export default App;