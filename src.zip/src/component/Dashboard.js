import React, {Component} from 'react';

class Dashboard extends Component {
    render() {
        return (
            <div>
                <h1>this is dashboard page.</h1>
            </div>
        );
    }
}

export default Dashboard;