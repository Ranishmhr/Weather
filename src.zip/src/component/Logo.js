
import React,{Component} from 'react';
class Logo extends Component{
  render (){
    return(
    <div className="Logo">
     Logo
    </div>
  );
}
}
export default Logo;