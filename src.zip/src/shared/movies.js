export default[
    {id:1, title: 'How you doin?', cover:'https://cdn.pixabay.com/photo/2019/08/26/16/41/sheep-4432232__340.jpg', genre:'comedy'},
    {id:2, title: 'I know', cover:'https://cdn.pixabay.com/photo/2019/08/26/16/41/sheep-4432232__340.jpg', genre:'comedy'},
    {id:3, title: 'Unagi', cover:'https://cdn.pixabay.com/photo/2019/08/26/16/41/sheep-4432232__340.jpg', genre:'comedy'},
    {id:4, title: 'Dinasours', cover:'https://cdn.pixabay.com/photo/2019/08/26/16/41/sheep-4432232__340.jpg', genre:'comedy'},
    {id:5, title: 'Coffee', cover:'https://cdn.pixabay.com/photo/2019/08/26/16/41/sheep-4432232__340.jpg', genre:'comedy'}
];