import React from "react";

const Moreinfo = props => (
<div>
    {
<p>this is more info</p>
    }
</div>
);
export default Moreinfo;