import React, {Component} from 'react';

class Settings extends Component {
    render() {
        return (
            <div>
                This is the settings page
            </div>
        );
    }
}

export default Settings;