import React,{Component} from 'react';
const API_KEY = "dd7f759d261762ebbb8cb130af247f30";

class WeekWeather extends Component{
    render(){
        
        return(
            <div>
                <h1>Hello world</h1>
            </div>
        );
    }
}

export default WeekWeather;